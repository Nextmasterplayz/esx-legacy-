Config = {}
Config.Locale = GetConvar('esx:locale', 'en')

Config.ToggleKey = "CAPITAL"
