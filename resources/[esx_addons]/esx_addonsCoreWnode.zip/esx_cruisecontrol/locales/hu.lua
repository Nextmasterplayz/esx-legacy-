Locales['hu'] = {
  ['activated']   = 'Bekapcsolva',
  ['deactivated'] = 'Kikapcsolva',
}
