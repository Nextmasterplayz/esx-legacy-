Locales['de'] = {
  ['activated']   = 'Aktivieren',
  ['deactivated'] = 'Deaktivieren',
}