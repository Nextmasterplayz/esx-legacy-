Locales['nl'] = {
  ['activated']   = 'geactiveerd',
  ['deactivated'] = 'gedeactiveerd',
}
