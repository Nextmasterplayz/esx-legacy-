Locales['it'] = {
  ['activated']   = 'attivato',
  ['deactivated'] = 'disattivato',
}
