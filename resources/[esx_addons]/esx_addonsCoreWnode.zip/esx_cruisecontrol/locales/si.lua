Locales['si'] = {
  ['activated']   = 'Aktivirano',
  ['deactivated'] = 'Deaktivirano',
}
