Locales['et'] = {
  ['invoices'] = 'Arved',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'Sa said ~r~arve',
  ['paid_invoice'] = 'Maksid arve maksumusega: ~r~$%s',
  ['no_invoices'] = 'Sul pole hetkel arveid',
  ['received_payment'] = 'Sa said makse summas: ~r~$%s',
  ['player_not_online'] = 'See isik pole linnas',
  ['no_money'] = 'Sul pole piisavalt raha, et maksta selle arve eest',
  ['target_no_money'] = 'Isikul ~r~pole raha, et maksta seda arvet!',
  ['keymap_showbills'] = 'Vaata arveid',
}
