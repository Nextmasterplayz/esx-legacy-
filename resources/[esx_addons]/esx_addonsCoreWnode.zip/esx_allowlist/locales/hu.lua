Locales['hu'] = {
  ['allowlist_check']     = 'Ellenőrizzük fent vagy-e a menők listáján.',
  ['not_allowlisted']     = 'Engedélyezettnek kell lenned ahhoz, hogy csatlakozz ehhez a szerverhez!',
  ['allowlist_empty']     = 'Ehhez a szerverhez nincsenek mentett engedélyezési lista.',
  ['license_missing']     = 'Hiba: Te azonosítód hiányzik!',
  ['help_allowlist_add']  = 'játékos felvétele az engedélyezettek listájára',
  ['help_allowlist_load'] = 'engedélyezési lista újratöltése',
}
