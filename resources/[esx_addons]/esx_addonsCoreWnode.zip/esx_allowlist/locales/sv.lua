Locales['sv'] = {
  ['allowlist_check']     = 'Ser till att du är vitlistad på den här servern. . .',
  ['not_allowlisted']     = 'Du är inte vitlistad på den här servern',
  ['allowlist_empty']     = 'Vitlistan har inte laddats ännu, eller alternativt har ingen blivit vitlistad!',
  ['license_missing']     = 'Din licens kunde inte hittas',
  ['help_allowlist_add']  = 'Lägg till någon på vitlistan',
  ['help_allowlist_load'] = 'Ladda om vitlistan',
}
