Locales['es'] = {
  ['allowlist_check']     = 'revisando si tienes la allowlist . . .',
  ['not_allowlisted']     = 'no tenes la allowlist en este servidor',
  ['allowlist_empty']     = 'La allowlist todavia no cargo, o alternativamente nadie la tiene',
  ['license_missing']     = 'no se pudo encontrar tu licencia',
  ['help_allowlist_add']  = 'agregar a la allowlist',
  ['help_allowlist_load'] = 'recargar allowlist',
}
