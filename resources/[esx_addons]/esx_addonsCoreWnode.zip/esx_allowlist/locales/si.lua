Locales['si'] = {
  ['allowlist_check'] = 'Preverja se, ali ste na seznamu dovoljenj.',
  ['not_allowlisted'] = 'Če se želite pridružiti temu strežniku, morate biti uvrščeni na seznam dovoljenj!',
  ['allowlist_empty'] = 'Za ta strežnik ni shranjenih belih seznamov.',
  ['license_missing'] = 'Napaka: Manjka vaš identifikator!',
  ['help_allowlist_add'] = 'Dodaj nekoga na beli seznam',
  ['help_allowlist_load'] = 'ponovno naložite belo listo',
}
