Locales['it'] = {
  ['allowlist_check']     = 'verifica Allowlisted.',
  ['not_allowlisted']     = 'devi essere nella Allowlisted per unirti a questo server!',
  ['allowlist_empty']     = 'non ci sono allowlists salvate per questo server.',
  ['license_missing']     = 'Errore: il tuo identificatore è mancante!',
  ['help_allowlist_add']  = 'aggiungi qualcuno alla allowlist',
  ['help_allowlist_load'] = 'ricarica la allowlist',
}
