Locales['tr'] = {
  ['allowlist_check']     = 'bu sunucuda beyaz listede olduğunuzdan emin olunuluyor . . .',
  ['not_allowlisted']     = 'bu sunucuda beyaz listede değilsiniz',
  ['allowlist_empty']     = 'beyaz liste henüz yüklenmedi yada beyaz listede kimse bulunmuyor',
  ['license_missing']     = 'lisansınız bulunamadı',
  ['help_allowlist_add']  = 'beyaz listeye birini ekle',
  ['help_allowlist_load'] = 'beyaz listeyi tekrardan yükle',
}
