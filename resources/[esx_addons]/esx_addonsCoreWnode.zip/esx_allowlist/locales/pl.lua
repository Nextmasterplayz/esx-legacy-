Locales['pl'] = {
  ['allowlist_check']     = 'Sprawdzamy, czy jesteś na Allowlist.',
  ['not_allowlisted']     = 'Aby dołączyć do tego serwera, musisz być na Allowlist!',
  ['allowlist_empty']     = 'Brak zapisanych list Allowlist dla tego serwera.',
  ['license_missing']     = 'Błąd: Brak ID!',
  ['help_allowlist_add']  = 'dodaj do allowlist',
  ['help_allowlist_load'] = 'przeładuj allowlist',
}
