Locales['de'] = {
    ['allowlist_check']     = 'Überprüfe ob sie auf der Allowlist sind...',
    ['not_allowlisted']     = 'Sie müssen auf der Allowlist sein, um diesem Server beizutreten!',
    ['allowlist_empty']     = 'Für diesen Server sind keine allowlists gespeichert.',
    ['license_missing']     = 'Error: Ihr Identifier fehlt.',
    ['help_allowlist_add']  = 'jemanden zur Allowlist hinzufügen',
    ['help_allowlist_load'] = 'lade die Allowlist neu',
  }
  