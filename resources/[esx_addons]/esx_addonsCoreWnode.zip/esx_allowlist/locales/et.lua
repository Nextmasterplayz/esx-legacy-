Locales['et'] = {
  ['allowlist_check']     = 'Kontrollime, kas te olete allowlistis.',
  ['not_allowlisted']     = 'Sa pead olema Allowlistis, et ühineda serveriga!',
  ['allowlist_empty']     = 'Ühtegi inimest pole allowlistis.',
  ['license_missing']     = 'Viga: Sul puudub identifier!',
  ['help_allowlist_add']  = 'Lisa inimene allowlisti',
  ['help_allowlist_load'] = 'Lae allowlist uuesti',
}
