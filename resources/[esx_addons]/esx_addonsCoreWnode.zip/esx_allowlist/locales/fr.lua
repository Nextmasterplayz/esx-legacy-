Locales['fr'] = {
  ['allowlist_check']     = 'Etes vous sûr d\'être allowlisté sur ce serveur ...',
  ['not_allowlisted']     = 'Ce serveur utilise une allowlist',
  ['allowlist_empty']     = 'La allowlist n\'a pas été rechargé ou vous n\'avez pas été allowlisté',
  ['license_missing']     = 'Votre license est introuvable',
  ['help_allowlist_add']  = 'Ajouter un joueur à la Whitelist',
  ['help_allowlist_load'] = 'Recharger la Whitelist',
}
