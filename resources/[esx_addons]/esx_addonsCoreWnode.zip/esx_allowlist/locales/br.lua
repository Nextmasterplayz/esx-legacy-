Locales['br'] = {
  ['allowlist_check']     = 'certificando-se de que você está na lista de permitidos(allowlist) neste servidor. . .',
  ['not_allowlisted']     = 'você não está na lista de permitidos(allowlist) neste servidor',
  ['steamid_error']       = 'seu ID do Steam não foi encontrado, o Steam está aberto?',
  ['allowlist_empty']     = 'a lista de permitidos(allowlist) ainda não foi carregada ou ninguém foi incluído!',
  ['help_allowlist_add']  = 'adicionar alguém à lista de permitidos(allowlist) no servidor',
  ['help_allowlist_load'] = 'recarregar a lista de permitidos(allowlist)',
}

