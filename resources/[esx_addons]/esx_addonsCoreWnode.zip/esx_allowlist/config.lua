Config = {}

Config.Locale = GetConvar('esx:locale', 'en')
Config.MinPlayer = 10    --Set how many players need to be connect before whitelist start, 0-32
