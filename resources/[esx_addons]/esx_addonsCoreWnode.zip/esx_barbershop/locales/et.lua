Locales['et'] = {
  ['valid_purchase'] = 'Kinnita ost?',
  ['yes'] = 'Jah',
  ['no'] = 'Ei',
  ['not_enough_money'] = 'Sul pole piisavalt raha.',
  ['press_access'] = 'Vajuta [E], et avada juuksuri menüü.',
  ['barber_blip'] = 'Juuksur',
  ['you_paid'] = 'Maksid $%s',
}
