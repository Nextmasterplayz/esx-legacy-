Locales['de'] = {
  ['valid_purchase'] = 'Einkauf bestätigen?',
  ['yes'] = 'ja',
  ['no'] = 'nein',
  ['not_enough_money'] = 'Du hast nicht genug Geld',
  ['press_access'] = 'Drücke [E] um das Menü zu öffnen',
  ['barber_blip'] = 'Friseur',
  ['you_paid'] = 'Du bezahlst $%s',
}