Locales['it'] = {
  ['valid_purchase'] = 'confermare l\'acquisto?',
  ['yes'] = 'si',
  ['no'] = 'no',
  ['not_enough_money'] = 'non hai abbastanza soldi',
  ['press_access'] = 'premi [E] per accedere al negozio.',
  ['barber_blip'] = 'barbiere',
  ['you_paid'] = 'hai pagato $%s',
}
