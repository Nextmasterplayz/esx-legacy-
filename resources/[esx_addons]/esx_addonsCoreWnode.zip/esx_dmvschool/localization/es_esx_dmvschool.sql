

INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Permiso teórico de conducir'),
	('drive', 'Permiso de conducir de coche'),
	('drive_bike', 'Permiso de conducir de moto'),
	('drive_truck', 'Permiso de conducir de camión')
;
