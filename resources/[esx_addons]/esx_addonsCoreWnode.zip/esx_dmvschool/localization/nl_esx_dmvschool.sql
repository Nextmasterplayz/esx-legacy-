INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Theorie examen'),
	('drive', 'Rijbewijs B'),
	('drive_bike', 'Motor Rijbewijs'),
	('drive_truck', 'Vrachtwagen Rijbewijs')
;
