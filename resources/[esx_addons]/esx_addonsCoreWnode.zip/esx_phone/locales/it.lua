Locales['it'] = {
  ['new_message'] = 'Hai ricevuto un messaggio: %s',
  ['press_take_call'] = '%s - Premi [E] per rispondere',
  ['taken_call'] = '%s chiamata in corso...',
  ['gps_position'] = 'La destinazione è stata aggiunta al tuo GPS',
  ['message_sent'] = 'Messaggio inviato',
  ['cannot_add_self'] = 'Non puoi aggiungere te stesso!',
  ['number_in_contacts'] = 'Questo numero è già presente nella lista contatti',
  ['contact_added'] = 'Contatto aggiunto!',
  ['contact_removed'] = 'Contatto rimosso!',
  ['number_not_assigned'] = 'Il numero non è stato assegnato!',
  ['invalid_number'] = 'Numero inserito non valido',
}
