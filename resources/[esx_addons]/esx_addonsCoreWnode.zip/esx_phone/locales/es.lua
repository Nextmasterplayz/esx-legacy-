Locales['es'] = {
  ['new_message'] = 'Nuevo mensaje : %s',
  ['press_take_call'] = '%s - Pulsar [E] para coger la llamada',
  ['taken_call'] = '%s ha contestado la llamada',
  ['gps_position'] = 'destino añadido al GPS',
  ['message_sent'] = 'mensaje enviado',
  ['cannot_add_self'] = 'no puedes agregarte a ti mismo!',
  ['number_in_contacts'] = 'este número ya está en tu lista de contactos',
  ['contact_added'] = 'contacto añadido!',
  ['contact_removed'] = 'el contacto ha sido eliminado!',
  ['number_not_assigned'] = 'el número no ha sido añadido!',
  ['invalid_number'] = 'el número no es válido!',
}

