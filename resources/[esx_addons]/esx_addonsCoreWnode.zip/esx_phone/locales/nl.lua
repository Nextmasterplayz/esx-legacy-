Locales['nl'] = {
  ['new_message'] = 'Je hebt een bericht ontvangen: %s',
  ['press_take_call'] = '%s - Klik op [E] om op te nemen',
  ['taken_call'] = '%s heeft opgenomen',
  ['gps_position'] = 'de bestemming is op je navigatie gezet',
  ['message_sent'] = 'het bericht is verstuurd',
  ['cannot_add_self'] = 'je kan jezelf niet toevoegen!',
  ['number_in_contacts'] = 'dit nummer staat al in je contacten',
  ['contact_added'] = 'je hebt een contact toegevoegd!',
  ['contact_removed'] = 'je hebt een contact verwijderd!',
  ['number_not_assigned'] = 'het nummer is nog niet toegewezen!',
  ['invalid_number'] = 'dat is een ongeldig nummer!',
}
