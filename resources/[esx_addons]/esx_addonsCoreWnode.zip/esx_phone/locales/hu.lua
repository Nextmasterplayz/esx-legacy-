Locales['hu'] = {
  ['new_message'] = 'Kaptál egy üzenetet: %s',
  ['press_take_call'] = '%s - Nyomd meg a [E] gombot a hívás fogadásához',
  ['taken_call'] = '%s fogadta a hívást',
  ['gps_position'] = 'az úti cél hozzáadva a GPS-hez.',
  ['message_sent'] = 'az üzenet elküldve',
  ['cannot_add_self'] = 'nem adhatod hozzá magad!',
  ['number_in_contacts'] = 'ez a szám már szerepel a névjegyzékében',
  ['contact_added'] = 'a névjegy hozzáadva!',
  ['contact_removed'] = 'a névjegy eltávolítva!',
  ['number_not_assigned'] = 'a szám nincs hozzárendelve!',
  ['invalid_number'] = 'ez nem érvényes szám!',
}
