Locales['br'] = {
  ['new_message'] = 'Nova mensagem : %s',
  ['press_take_call'] = '%s - Pressione [E] para aceitar a chamada',
  ['taken_call'] = '%s recebeu uma chamada',
  ['gps_position'] = 'destino inserido no GPS',
  ['message_sent'] = 'mensagem enviada',
  ['cannot_add_self'] = 'você não pode se adicionar',
  ['number_in_contacts'] = 'este número já está na sua lista de contatos',
  ['contact_added'] = 'contato adicionado',
  ['contact_removed'] = 'the contact has been removed!',
  ['number_not_assigned'] = 'este número não foi atribuído...',
  ['invalid_number'] = 'that\'s not an valid number!',
}
