Locales['en'] = {
	
	['used_beer'] = 'you used 1x Beer',

}