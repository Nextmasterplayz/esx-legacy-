Locales['si'] = {
	
	['used_beer'] = 'Uporabil si 1x Pivo',

}