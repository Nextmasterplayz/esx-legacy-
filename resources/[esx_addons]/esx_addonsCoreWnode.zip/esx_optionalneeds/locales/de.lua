Locales['de'] = {
	
	['used_beer'] = 'Du hast 1x Bier getrunken',

}