Locales['pl'] = {
	
	['used_beer'] = 'używasz 1x Piwo',

}