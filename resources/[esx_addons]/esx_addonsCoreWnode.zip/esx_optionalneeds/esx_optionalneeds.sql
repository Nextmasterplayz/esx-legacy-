

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('beer', 'Beer', 1)
;
