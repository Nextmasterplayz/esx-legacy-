

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('beer', 'Sör', 1)
;
