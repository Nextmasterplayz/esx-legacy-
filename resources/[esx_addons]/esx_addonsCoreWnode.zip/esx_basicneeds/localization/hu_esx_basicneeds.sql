

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Kenyér', 1),
	('water', 'Víz', 1)
;
