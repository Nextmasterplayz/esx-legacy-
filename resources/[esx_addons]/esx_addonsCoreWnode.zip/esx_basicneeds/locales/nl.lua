Locales['nl'] = {
    ['used_eat'] = 'je hebt 1x %s gegeten',
    ['used_drink'] = 'je hebt 1x %s gedronken',
  }
