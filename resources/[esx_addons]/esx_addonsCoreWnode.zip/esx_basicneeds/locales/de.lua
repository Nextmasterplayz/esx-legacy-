Locales['de'] = {
  ['used_food'] = 'Du hast 1x %s gegessen.',
  ['used_drink'] = 'Du hast 1x %s getrunken.',
  ['got_healed'] = 'Du wurdest geheilt.'
}
