Locales['en'] = {
  ['used_food'] = 'You have eaten 1x %s',
  ['used_drink'] = 'You have drinked 1x %s',
  ['got_healed'] = 'You have been healed.'
}
