Locales['et'] = {
  ['used_eat'] = 'Sõid 1x %s',
  ['used_drink'] = 'Jõid 1x %s',
}
