Locales['br'] = {
  ['used_eat'] = 'você comeu 1x %s',
  ['used_drink'] = 'você tomou 1x  %s',
}
