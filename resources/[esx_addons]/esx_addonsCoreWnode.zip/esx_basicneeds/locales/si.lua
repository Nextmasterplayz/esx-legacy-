Locales['si'] = {
  ['used_bread'] = 'uporabili ste 1x bread',
  ['used_water'] = 'uporabili ste 1x water',
}