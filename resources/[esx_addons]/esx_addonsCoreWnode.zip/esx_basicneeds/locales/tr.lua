Locales['tr'] = {
	['used_bread'] = '1x ekmek kullandın',
	['used_water'] = '1x su kullandın',
}
