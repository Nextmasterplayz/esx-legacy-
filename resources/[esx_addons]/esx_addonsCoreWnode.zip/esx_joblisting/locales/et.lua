Locales['et'] = {
  ['new_job'] = 'Uus töökoht: ~b~%s~s~ !',
  ['access_job_center'] = 'Vajuta ~b~[E]~s~, et avada töötukassa menüü.',
  ['job_center'] = 'Vali töökoht.',
  ["blip_text"] = "Töötukassa"
}
