Locales['en'] = {
  ['new_job'] = 'New Job: ~b~%s~s~ !',
  ['access_job_center'] = 'Press ~b~[E]~s~ To Open Job Selector.',
  ['job_center'] = 'Select A Job.',
  ["blip_text"] = "Job Centre"
}
