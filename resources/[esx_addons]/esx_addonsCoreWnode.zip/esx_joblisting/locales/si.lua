Locales['si'] = {
  ['new_job'] = 'imaš novo službo!',
  ['access_job_center'] = 'pritisnite ~INPUT_PICKUP~ za dostop do job center.',
  ['job_center'] = 'center za delovna mesta',
}
