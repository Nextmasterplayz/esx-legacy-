Locales['hu'] = {
  ['new_job'] = 'Felvetted a munkát!',
  ['access_job_center'] = 'Nyomj ~b~[E]~s~ hogy megnézd a munkákat',
  ['job_center'] = 'Munkaügyi központ',
}
