Locales['fi'] = {
  ['new_job'] = 'Sinulla on nyt uusi työ !',
  ['access_job_center'] = 'paina ~INPUT_PICKUP~ vaihtaaksesi työtä työkeskuksessa.',
  ['job_center'] = 'työkeskus',
}
