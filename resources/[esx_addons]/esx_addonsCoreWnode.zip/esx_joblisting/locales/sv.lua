Locales['sv'] = {
  ['new_job'] = 'du har ett nytt jobb! Tips: kolla kartan för nya blips.',
  ['access_job_center'] = 'tryck ~INPUT_PICKUP~ för att öppna arbetsförmedlingen',
  ['job_center'] = 'arbetsförmedlingen',
}
