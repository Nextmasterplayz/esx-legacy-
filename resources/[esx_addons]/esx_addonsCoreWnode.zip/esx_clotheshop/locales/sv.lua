Locales['sv'] = {
  ['valid_this_purchase'] = 'vill du köpa dessa kläder?',
  ['yes'] = 'ja',
  ['no'] = 'nej',
  ['not_enough_money'] = 'du har ~r~inte råd för att köpa detta',
  ['press_menu'] = 'tryck [E] för att öppna klädesaffären.',
  ['clothes'] = 'klädesaffär',
  ['you_paid'] = 'du har betalat $%s',
  ['save_in_dressing'] = 'vill du spara outfiten i din fastighet?',
  ['name_outfit'] = 'vad ska din outfit heta?',
  ['saved_outfit'] = 'outfit har sparats!',
}