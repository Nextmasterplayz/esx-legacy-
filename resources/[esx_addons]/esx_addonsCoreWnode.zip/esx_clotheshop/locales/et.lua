Locales['et'] = {
  ['valid_this_purchase'] = 'Kinnita see ost?',
  ['yes'] = 'jah',
  ['no'] = 'Ei',
  ['not_enough_money'] = 'Sul pole piisavalt raha',
  ['press_menu'] = 'Vajuta [E], et avada riidepood.',
  ['clothes'] = 'Riidepood',
  ['you_paid'] = 'Sa maksid $%s',
  ['save_in_dressing'] = 'Kas soovite sellist paari riideid ka enda korteri?',
  ['name_outfit'] = 'Pane riietusele nimi',
  ['saved_outfit'] = 'Riietus salvestatud!',
}
