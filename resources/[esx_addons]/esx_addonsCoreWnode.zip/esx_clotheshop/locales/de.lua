Locales['de'] = {
  ['valid_this_purchase'] = 'Einkauf bestätigen?',
  ['yes'] = 'ja',
  ['no'] = 'nein',
  ['not_enough_money'] = 'Du hast nicht genug Geld',
  ['press_menu'] = 'Drücke [E] um das Menü zu öffnen',
  ['clothes'] = 'Kleidung',
  ['you_paid'] = 'Du bezahlst $%s',
  ['save_in_dressing'] = 'Wollen sie das Outfit in ihrer Garderobe speichern?',
  ['name_outfit'] = 'Name des outfits?',
  ['saved_outfit'] = 'Das outfit wurde gespeichert',
}